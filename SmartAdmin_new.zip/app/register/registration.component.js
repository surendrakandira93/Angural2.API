"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var data_service_1 = require('../shared/services/data.service');
var items_service_1 = require('../shared/utils/items.service');
var notification_service_1 = require('../shared/utils/notification.service');
var ng2_slim_loading_bar_1 = require('ng2-slim-loading-bar');
var RegistrationComponent = (function () {
    function RegistrationComponent(dataService, router, itemsService, notificationService, loadingBarService) {
        this.dataService = dataService;
        this.router = router;
        this.itemsService = itemsService;
        this.notificationService = notificationService;
        this.loadingBarService = loadingBarService;
        this.model = {};
        this.loading = false;
    }
    RegistrationComponent.prototype.ngOnInit = function () {
        // reset login status
        //this.dataService.logout();
    };
    RegistrationComponent.prototype.registration = function () {
        var _this = this;
        this.loading = true;
        this.dataService.register(this.model.username, this.model.firstName, this.model.lastName, this.model.password)
            .subscribe(function (data) {
            _this.router.navigate(['/login']);
        }, function (error) {
            //this.alertService.error(error);
            _this.loading = false;
        });
    };
    RegistrationComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: 'registration.component.html'
        }), 
        __metadata('design:paramtypes', [data_service_1.DataService, router_1.Router, items_service_1.ItemsService, notification_service_1.NotificationService, ng2_slim_loading_bar_1.SlimLoadingBarService])
    ], RegistrationComponent);
    return RegistrationComponent;
}());
exports.RegistrationComponent = RegistrationComponent;
//# sourceMappingURL=registration.component.js.map