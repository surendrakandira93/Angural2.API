﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/services/data.service';
import { ItemsService } from '../shared/utils/items.service';
import { NotificationService } from '../shared/utils/notification.service';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
    moduleId: module.id,
    templateUrl: 'registration.component.html'
})

export class RegistrationComponent implements OnInit {
    model: any = {};
    loading = false;

    constructor(private dataService: DataService,
        private router: Router,
        private itemsService: ItemsService,
        private notificationService: NotificationService,
        private loadingBarService: SlimLoadingBarService) { }

    ngOnInit() {
        // reset login status
        //this.dataService.logout();
    }

    registration() {
        this.loading = true;
        this.dataService.register(this.model.username, this.model.firstName, this.model.lastName, this.model.password)
            .subscribe(
            data => {
                this.router.navigate(['/login']);
            },
            error => {
                //this.alertService.error(error);
                this.loading = false;
            });
    }
}
