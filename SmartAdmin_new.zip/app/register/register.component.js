"use strict";
var RegisterComponent = (function () {
    function RegisterComponent(dataService, router, itemsService, notificationService, loadingBarService) {
        this.dataService = dataService;
        this.router = router;
        this.itemsService = itemsService;
        this.notificationService = notificationService;
        this.loadingBarService = loadingBarService;
        this.model = {};
        this.loading = false;
    }
    RegisterComponent.prototype.register = function () {
        var _this = this;
        this.loading = true;
        this.dataService.register(this.model.username, this.model.firstName, this.model.lastName, this.model.password)
            .subscribe(function (data) {
            _this.notificationService.printSuccessMessage(_this.model.username + ' Registration successful !');
            _this.router.navigate(['/login']);
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to register ' + _this.model.username + ' ' + error);
            _this.loading = false;
        });
    };
    return RegisterComponent;
}());
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=register.component.js.map