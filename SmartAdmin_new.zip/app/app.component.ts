﻿import { Component, OnInit, ViewContainerRef } from '@angular/core';

// Add the RxJS Observable operators we need in this app.
import { DataService } from '../app/shared/services/data.service';
import { ICurrentUser } from '../app/shared/interfaces';
import { Router } from '@angular/router';
import './rxjs-operators';

@Component({
    selector: 'scheduler',
    templateUrl: 'app/app.component.html'
})
export class AppComponent {
    currentUser: ICurrentUser;
    Islogin: boolean;

    constructor(private dataService: DataService,
        private router: Router,
        private viewContainerRef: ViewContainerRef) {
        // You need this small hack in order to catch application root view container ref
        this.viewContainerRef = viewContainerRef;
        if (localStorage.getItem('currentUser') != null) {            
            let currrr = JSON.parse(localStorage.getItem('currentUser'));
           this.Islogin = true;
            this.currentUser = currrr;            
        }
        else {
            this.Islogin = false;
            this.router.navigate(['/login']);

        }
    }

    LogoutUser() {
        this.dataService.logout();
        this.router.navigate(['/']);
    }
}