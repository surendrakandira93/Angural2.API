﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
//Grab everything with import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {ICategory, IUser, ICurrentUser, ISchedule, IScheduleDetails, Pagination, PaginatedResult } from '../interfaces';
import { ItemsService } from '../utils/items.service';
import { ConfigService } from '../utils/config.service';

@Injectable()
export class DataService {

    _baseUrl: string = '';
    
    constructor(private http: Http,
        private itemsService: ItemsService,
        private configService: ConfigService) {
        this._baseUrl = configService.getApiURI();
    }

    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.access_token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.access_token });
            headers.append("Content-Type", "application/json");              
            return new RequestOptions({ headers: headers });
        }
    }
    getCategories(): Observable<ICategory[]> {       
        return this.http.get(this._baseUrl + 'Cat/All', this.jwt())
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    createCategory(category: ICategory): Observable<ICategory> {           
        return this.http.post(this._baseUrl + 'Cat/Save', category, this.jwt()).map((res: Response) => {
            return res.json()
            })
            .catch(this.handleError)
    }
    login(username: string, password: string): Observable<ICurrentUser> {
        let header = new Headers();
        header.append("Content-Type", "application/x-www-form-urlencoded");
        let data = "grant_type=password&username=" + username + "&password=" + password;        
        return this.http.post(this._baseUrl+'token', data, {
            headers: header
        }).map((res: Response) => {
            return res.json()
        })
            .catch(this.handleError)
    }  
    
    register(userName,firstName,lastName,password) {
        let header = new Headers();
        header.append("Content-Type", "application/json");
        let data = {
            username: userName, firstName: firstName, lastName: lastName, password: password  }
        return this.http.post(this._baseUrl +'Account/Register', data, {
            headers: header
        }).map((res: Response) => {
            return res.json()
        })
            .catch(this.handleError)
    }

    logout() {
        localStorage.removeItem('currentUser');
    }
    updateCat(category: ICategory): Observable<ICategory> {          
        return this.http.put(this._baseUrl + 'Cat/Update', category, this.jwt())
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    deleteCat(category: ICategory): Observable<void> {
        return this.http.delete(this._baseUrl + 'Cat/Delete?id=' + category.id, this.jwt())
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    getUsers(): Observable<IUser[]> {
        let headers = new Headers();
       // headers.append('Content-Type', 'application/json');
        //headers.append('Accept','application/json' );

        return this.http.get(this._baseUrl + 'users',{
            headers: headers
        })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    getUserSchedules(id: number): Observable<ISchedule[]> {
        return this.http.get(this._baseUrl + 'users/' + id + '/schedules')
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    createUser(user: IUser): Observable<IUser> {
        console.log("createUser");
        console.log(user);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.post(this._baseUrl + 'users', user, {
            headers: headers
        })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    updateUser(user: IUser): Observable<void> {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');      

        return this.http.put(this._baseUrl + 'users/'+user.id, user, {
            headers: headers
        })
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    deleteUser(id: number): Observable<void> {
        return this.http.delete(this._baseUrl + 'users/' + id)
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    /*
    getSchedules(page?: number, itemsPerPage?: number): Observable<ISchedule[]> {
        let headers = new Headers();
        if (page != null && itemsPerPage != null) {
            headers.append('Pagination', page + ',' + itemsPerPage);
        }

        return this.http.get(this._baseUrl + 'schedules', {
            headers: headers
        })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }
    */

    getSchedules(page?: number, itemsPerPage?: number): Observable<PaginatedResult<ISchedule[]>> {
        var peginatedResult: PaginatedResult<ISchedule[]> = new PaginatedResult<ISchedule[]>();

        let headers = new Headers();
        if (page != null && itemsPerPage != null) {
            headers.append('Pagination', page + ',' + itemsPerPage);
        }

        return this.http.get(this._baseUrl + 'schedules', {
            headers: headers
        })
            .map((res: Response) => {
                console.log(res.headers.keys());
                peginatedResult.result = res.json();

                if (res.headers.get("Pagination") != null) {
                    //var pagination = JSON.parse(res.headers.get("Pagination"));
                    var paginationHeader: Pagination = this.itemsService.getSerialized<Pagination>(JSON.parse(res.headers.get("Pagination")));
                    console.log(paginationHeader);
                    peginatedResult.pagination = paginationHeader;
                }
                return peginatedResult;
            })
            .catch(this.handleError);
    }

    getSchedule(id: number): Observable<ISchedule> {
        return this.http.get(this._baseUrl + 'schedules/' + id)
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    getScheduleDetails(id: number): Observable<IScheduleDetails> {
        return this.http.get(this._baseUrl + 'schedules/' + id +'/details')
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    updateSchedule(schedule: ISchedule): Observable<void> {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.put(this._baseUrl + 'schedules/' + schedule.id, JSON.stringify(schedule), {
            headers: headers
        })
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    deleteSchedule(id: number): Observable<void> {
        return this.http.delete(this._baseUrl + 'schedules/' + id)
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    deleteScheduleAttendee(id: number, attendee: number) {

        return this.http.delete(this._baseUrl + 'schedules/' + id + '/removeattendee/' + attendee)
            .map((res: Response) => {
                return;
            })
            .catch(this.handleError);
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }
}