import { Component, Input, Output, OnInit, EventEmitter, ViewChild } from '@angular/core';

import { DataService } from '../shared/services/data.service';
import { ItemsService } from '../shared/utils/items.service';
import { NotificationService } from '../shared/utils/notification.service';
import { ICategory } from '../shared/interfaces';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
    moduleId: module.id,
    selector: 'Cats',
    templateUrl: 'cat-list.component.html'
})


export class CatListComponent implements OnInit {

    @ViewChild('childModal') public childModal: ModalDirective;
    @Input() category: ICategory;
    @Output() removeCat = new EventEmitter();
    @Output() catCreated = new EventEmitter();

    newcategory: ICategory;
    Categories: ICategory[];
    addingCat: boolean = false;
    onEdit: boolean = false;
    apiHost: string;

    @ViewChild('modal')
    modal: any;

    constructor(private dataService: DataService,
        private itemsService: ItemsService,
        private notificationService: NotificationService,
        private loadingBarService: SlimLoadingBarService) { }

    ngOnInit() {
        this.newcategory = { name: '', id: 0 };
        this.dataService.getCategories()
            .subscribe((Categories: ICategory[]) => {
                this.Categories = Categories;
            },
            error => {
                this.notificationService.printErrorMessage('Failed to load Categories. ' + error);
            });

    }

    CategoryEidt(cat: ICategory) {
        this.newcategory = cat;
        this.onEdit = true;
        this.childModal.show();
    }

    CategoryDelete(cat: ICategory) {
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + cat.name + ' from this Category?',
            () => {
                this.loadingBarService.start();
                this.dataService.deleteCat(cat).subscribe(() => {
                    this.itemsService.removeItemFromArray<ICategory>(this.Categories, cat);
                    this.notificationService.printSuccessMessage(cat.name + ' Delete successfully !');
                    this.loadingBarService.complete();
                }, error=> {
                    this.loadingBarService.complete();
                    this.notificationService.printErrorMessage('Failed to remove ' + cat.name + ' ' + error);
                })
            })
    }

    addCat() {
        this.newcategory = { name: '', id: 0 };
        this.onEdit = false;
        this.childModal.show();
    }

    createCat() {
        this.dataService.createCategory(this.newcategory)
            .subscribe((category: ICategory) => {
                this.newcategory = category;
                this.onEdit = false;
                this.catCreated.emit({ value: category });
                //this.slimLoader.complete();
                this.itemsService.addItemToStart<ICategory>(this.Categories, category);
            },
            error => {
                this.notificationService.printErrorMessage('Failed to created Cat');
                this.notificationService.printErrorMessage(error);
                //this.slimLoader.complete();
            });
        this.childModal.hide();
    }

    UpdateCat() {       
        //this.slimLoader.start();
        this.dataService.updateCat(this.newcategory)
            .subscribe(() => {
                this.category = this.newcategory;
                this.onEdit = !this.onEdit;
                this.notificationService.printSuccessMessage(this.category.name + ' has been updated');
                //this.slimLoader.complete();
                this.childModal.hide();
            },
            error => {
                this.notificationService.printErrorMessage('Failed to edit user');
                this.notificationService.printErrorMessage(error);
                //this.slimLoader.complete();
                this.childModal.hide();
            });
    }

    openRemoveModal() {
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + this.category.name + '?',
            () => {
                //this.slimLoader.start();
                this.dataService.deleteUser(this.category.id)
                    .subscribe(
                    res => {
                        this.removeCat.emit({
                            value: this.category
                        });
                        //this.slimLoader.complete();
                        //this.slimLoader.complete();
                    }, error => {
                        this.notificationService.printErrorMessage(error);
                        //this.slimLoader.complete();
                    })
            });
    }

    public hideChildModal(): void {
        this.childModal.hide();
    }

    isCatValid(): boolean {
        return !(this.newcategory.name.trim() === "");
    }


}