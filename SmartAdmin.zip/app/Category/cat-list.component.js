"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var data_service_1 = require('../shared/services/data.service');
var items_service_1 = require('../shared/utils/items.service');
var notification_service_1 = require('../shared/utils/notification.service');
var ng2_slim_loading_bar_1 = require('ng2-slim-loading-bar');
var ng2_bootstrap_1 = require('ng2-bootstrap');
var CatListComponent = (function () {
    function CatListComponent(dataService, itemsService, notificationService, loadingBarService) {
        this.dataService = dataService;
        this.itemsService = itemsService;
        this.notificationService = notificationService;
        this.loadingBarService = loadingBarService;
        this.removeCat = new core_1.EventEmitter();
        this.catCreated = new core_1.EventEmitter();
        this.addingCat = false;
        this.onEdit = false;
    }
    CatListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.newcategory = { name: '', id: 0 };
        this.dataService.getCategories()
            .subscribe(function (Categories) {
            _this.Categories = Categories;
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to load Categories. ' + error);
        });
    };
    CatListComponent.prototype.CategoryEidt = function (cat) {
        this.newcategory = cat;
        this.onEdit = true;
        this.childModal.show();
    };
    CatListComponent.prototype.CategoryDelete = function (cat) {
        var _this = this;
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + cat.name + ' from this Category?', function () {
            _this.loadingBarService.start();
            _this.dataService.deleteCat(cat).subscribe(function () {
                _this.itemsService.removeItemFromArray(_this.Categories, cat);
                _this.notificationService.printSuccessMessage(cat.name + ' Delete successfully !');
                _this.loadingBarService.complete();
            }, function (error) {
                _this.loadingBarService.complete();
                _this.notificationService.printErrorMessage('Failed to remove ' + cat.name + ' ' + error);
            });
        });
    };
    CatListComponent.prototype.addCat = function () {
        this.newcategory = { name: '', id: 0 };
        this.onEdit = false;
        this.childModal.show();
    };
    CatListComponent.prototype.createCat = function () {
        var _this = this;
        this.dataService.createCategory(this.newcategory)
            .subscribe(function (category) {
            _this.newcategory = category;
            _this.onEdit = false;
            _this.catCreated.emit({ value: category });
            //this.slimLoader.complete();
            _this.itemsService.addItemToStart(_this.Categories, category);
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to created Cat');
            _this.notificationService.printErrorMessage(error);
            //this.slimLoader.complete();
        });
        this.childModal.hide();
    };
    CatListComponent.prototype.UpdateCat = function () {
        var _this = this;
        //this.slimLoader.start();
        this.dataService.updateCat(this.newcategory)
            .subscribe(function () {
            _this.category = _this.newcategory;
            _this.onEdit = !_this.onEdit;
            _this.notificationService.printSuccessMessage(_this.category.name + ' has been updated');
            //this.slimLoader.complete();
            _this.childModal.hide();
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to edit user');
            _this.notificationService.printErrorMessage(error);
            //this.slimLoader.complete();
            _this.childModal.hide();
        });
    };
    CatListComponent.prototype.openRemoveModal = function () {
        var _this = this;
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + this.category.name + '?', function () {
            //this.slimLoader.start();
            _this.dataService.deleteUser(_this.category.id)
                .subscribe(function (res) {
                _this.removeCat.emit({
                    value: _this.category
                });
                //this.slimLoader.complete();
                //this.slimLoader.complete();
            }, function (error) {
                _this.notificationService.printErrorMessage(error);
                //this.slimLoader.complete();
            });
        });
    };
    CatListComponent.prototype.hideChildModal = function () {
        this.childModal.hide();
    };
    CatListComponent.prototype.isCatValid = function () {
        return !(this.newcategory.name.trim() === "");
    };
    __decorate([
        core_1.ViewChild('childModal'), 
        __metadata('design:type', ng2_bootstrap_1.ModalDirective)
    ], CatListComponent.prototype, "childModal", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], CatListComponent.prototype, "category", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], CatListComponent.prototype, "removeCat", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], CatListComponent.prototype, "catCreated", void 0);
    __decorate([
        core_1.ViewChild('modal'), 
        __metadata('design:type', Object)
    ], CatListComponent.prototype, "modal", void 0);
    CatListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'Cats',
            templateUrl: 'cat-list.component.html'
        }), 
        __metadata('design:paramtypes', [data_service_1.DataService, items_service_1.ItemsService, notification_service_1.NotificationService, ng2_slim_loading_bar_1.SlimLoadingBarService])
    ], CatListComponent);
    return CatListComponent;
}());
exports.CatListComponent = CatListComponent;
//# sourceMappingURL=cat-list.component.js.map