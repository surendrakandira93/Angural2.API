﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/services/data.service';
import { ItemsService } from '../shared/utils/items.service';
import { NotificationService } from '../shared/utils/notification.service';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { ModalDirective } from 'ng2-bootstrap';



export class RegisterComponent {
    model: any = {};
    loading = false;

    constructor(private dataService: DataService,
        private router: Router,
        private itemsService: ItemsService,
        private notificationService: NotificationService,
        private loadingBarService: SlimLoadingBarService) { }

  

    register() {
        this.loading = true;
        this.dataService.register(this.model.username, this.model.firstName, this.model.lastName, this.model.password)
            .subscribe(
            data => {
                this.notificationService.printSuccessMessage(this.model.username + ' Registration successful !');               
                this.router.navigate(['/login']);
            },
            error => {
               
                this.notificationService.printErrorMessage('Failed to register ' + this.model.username + ' ' + error);
                this.loading = false;
            });
    }
}
