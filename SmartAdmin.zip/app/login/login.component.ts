﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/services/data.service';
import { ItemsService } from '../shared/utils/items.service';
import { NotificationService } from '../shared/utils/notification.service';
import { ICurrentUser } from '../shared/interfaces';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
    moduleId: module.id,
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    model: any = {};
    loading = false;
    currentUser: ICurrentUser;
    constructor(private dataService: DataService,
        private router: Router,
        private itemsService: ItemsService,
        private notificationService: NotificationService,
        private loadingBarService: SlimLoadingBarService)  { }

    ngOnInit() {
        
        if (localStorage.getItem('currentUser') != null) {
            let currrr = JSON.parse(localStorage.getItem('currentUser'));
            this.currentUser = currrr;
            if (parseInt(currrr['Id']) > 0) {
                this.router.navigate(['/Category']);
            }
            else {

                this.dataService.logout();
            }
        }
        else {
            this.dataService.logout();

        }
    }

    login() {
        this.loading = true;
        this.dataService.login(this.model.username, this.model.password)
            .subscribe((currentUser: ICurrentUser)=>{                
                this.currentUser = currentUser;
                localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
                    this.router.navigate(['']);
                },
                error => {
                    //this.alertService.error(error);
                    this.loading = false;
                });
    }
}
