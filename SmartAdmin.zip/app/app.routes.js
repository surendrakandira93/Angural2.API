"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('./home/home.component');
var user_list_component_1 = require('./users/user-list.component');
var cat_list_component_1 = require('./Category/cat-list.component');
var login_component_1 = require('./login/login.component');
var registration_component_1 = require('./register/registration.component');
var appRoutes = [
    { path: 'users', component: user_list_component_1.UserListComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: 'register', component: registration_component_1.RegistrationComponent },
    { path: 'Category', component: cat_list_component_1.CatListComponent },
    { path: '', component: home_component_1.HomeComponent }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routes.js.map