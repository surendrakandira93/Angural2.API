"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var data_service_1 = require('../shared/services/data.service');
var items_service_1 = require('../shared/utils/items.service');
var notification_service_1 = require('../shared/utils/notification.service');
var ng2_bootstrap_1 = require('ng2-bootstrap');
var UserListComponent = (function () {
    function UserListComponent(dataService, itemsService, notificationService) {
        this.dataService = dataService;
        this.itemsService = itemsService;
        this.notificationService = notificationService;
        this.addingUser = false;
    }
    UserListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dataService.getUsers()
            .subscribe(function (users) {
            _this.users = users;
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to load users. ' + error);
        });
    };
    UserListComponent.prototype.EidtUSer = function (user) {
        this.newUser = user;
        this.addingUser = true;
        this.childModal.show();
    };
    UserListComponent.prototype.removeUser = function (user) {
        var _this = this;
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + user.FirstName + ' from this User?', function () {
            _this.dataService.deleteUser(user.Id).subscribe(function () {
                _this.itemsService.removeItemFromArray(_this.users, user);
                _this.notificationService.printSuccessMessage(user.FirstName + ' Delete successfully !');
            }, function (error) {
                _this.notificationService.printErrorMessage('Failed to remove ' + user.name + ' ' + error);
            });
        });
    };
    UserListComponent.prototype.createUser = function () {
        var _this = this;
        this.dataService.createUser(this.newUser)
            .subscribe(function (user) {
            _this.addingUser = false;
            _this.itemsService.addItemToStart(_this.users, user);
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to created user');
            _this.notificationService.printErrorMessage(error);
            //this.slimLoader.complete();
        });
        this.childModal.hide();
    };
    UserListComponent.prototype.UpdateUser = function () {
        var _this = this;
        //this.slimLoader.start();
        this.dataService.updateUser(this.newUser)
            .subscribe(function () {
            _this.addingUser = !_this.addingUser;
            _this.notificationService.printSuccessMessage(_this.newUser.FirstName + ' has been updated');
            //this.slimLoader.complete();
            _this.childModal.hide();
        }, function (error) {
            _this.notificationService.printErrorMessage('Failed to edit user');
            _this.notificationService.printErrorMessage(error);
            //this.slimLoader.complete();
            _this.childModal.hide();
        });
    };
    UserListComponent.prototype.addUser = function () {
        this.newUser = { FirstName: '', LastName: '', Id: 0, Email: '', Address: '', DateOfBirth: new Date(), ProfilePhoto: '' };
        this.addingUser = true;
        this.childModal.show();
    };
    UserListComponent.prototype.cancelAddUser = function () {
        this.addingUser = false;
        this.itemsService.removeItems(this.users, function (x) { return x.id < 0; });
    };
    __decorate([
        core_1.ViewChild('childModal'), 
        __metadata('design:type', ng2_bootstrap_1.ModalDirective)
    ], UserListComponent.prototype, "childModal", void 0);
    __decorate([
        core_1.ViewChild('modal'), 
        __metadata('design:type', Object)
    ], UserListComponent.prototype, "modal", void 0);
    UserListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'users',
            templateUrl: 'user-list.component.html'
        }), 
        __metadata('design:paramtypes', [data_service_1.DataService, items_service_1.ItemsService, notification_service_1.NotificationService])
    ], UserListComponent);
    return UserListComponent;
}());
exports.UserListComponent = UserListComponent;
//# sourceMappingURL=user-list.component.js.map