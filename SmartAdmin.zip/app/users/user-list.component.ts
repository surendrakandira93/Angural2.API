import { Component, OnInit, ViewChild} from '@angular/core';

import { DataService } from '../shared/services/data.service';
import { ItemsService } from '../shared/utils/items.service';
import { NotificationService } from '../shared/utils/notification.service';
import { IUser } from '../shared/interfaces';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
    moduleId: module.id,
    selector: 'users',
    templateUrl: 'user-list.component.html'
})
export class UserListComponent implements OnInit {
    @ViewChild('childModal') public childModal: ModalDirective;

    newUser: IUser;
    users: IUser[];
    addingUser: boolean = false;

    @ViewChild('modal')
    modal: any;

    constructor(private dataService: DataService,
        private itemsService: ItemsService,
        private notificationService: NotificationService) { }

    ngOnInit() {
        this.dataService.getUsers()
            .subscribe((users: IUser[]) => {
                this.users = users;
            },
            error => {
                this.notificationService.printErrorMessage('Failed to load users. ' + error);
            });
    }

    EidtUSer(user: IUser) {
        this.newUser = user;
        this.addingUser = true;
        this.childModal.show();
    }

    removeUser(user: IUser) {
        this.notificationService.openConfirmationDialog('Are you sure you want to remove '
            + user.FirstName + ' from this User?',
            () => {

                this.dataService.deleteUser(user.Id).subscribe(() => {
                    this.itemsService.removeItemFromArray<IUser>(this.users, user);
                    this.notificationService.printSuccessMessage(user.FirstName + ' Delete successfully !');
                }, error=> {
                    this.notificationService.printErrorMessage('Failed to remove ' + user.name + ' ' + error);
                })
            })
    }

    createUser() {
        this.dataService.createUser(this.newUser)
            .subscribe((user: IUser) => {
                this.addingUser = false;
                this.itemsService.addItemToStart<IUser>(this.users, user);
            },
            error => {
                this.notificationService.printErrorMessage('Failed to created user');
                this.notificationService.printErrorMessage(error);
                //this.slimLoader.complete();
            });
        this.childModal.hide();
    }

    UpdateUser() {       
        //this.slimLoader.start();
        this.dataService.updateUser(this.newUser)
            .subscribe(() => {
                this.addingUser = !this.addingUser;
                this.notificationService.printSuccessMessage(this.newUser.FirstName + ' has been updated');
                //this.slimLoader.complete();
                this.childModal.hide();
            },
            error => {
                this.notificationService.printErrorMessage('Failed to edit user');
                this.notificationService.printErrorMessage(error);
                //this.slimLoader.complete();
                this.childModal.hide();
            });
    }

    addUser() {
        this.newUser = { FirstName: '', LastName: '', Id: 0, Email: '', Address: '', DateOfBirth: new Date(), ProfilePhoto: '' };
        this.addingUser = true;
        this.childModal.show();
    }

    cancelAddUser() {
        this.addingUser = false;
        this.itemsService.removeItems<IUser>(this.users, x => x.id < 0);
    }
}