﻿export interface ICategory {
    id: number;
    name: string;  
}


export interface IUser {
    Id: number;
    FirstName: string;
    LastName: string;
    Email: string;
    DateOfBirth: Date;
    ProfilePhoto: string;
    Address: string;
}


export interface ICurrentUser {
    Id: number;
    access_token: string;    
    userName: string;
    fullName: string;
}