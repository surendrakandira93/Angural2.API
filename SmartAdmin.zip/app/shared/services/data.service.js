"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
//Grab everything with import 'rxjs/Rx';
var Observable_1 = require('rxjs/Observable');
require('rxjs/add/operator/map');
require('rxjs/add/operator/catch');
var items_service_1 = require('../utils/items.service');
var config_service_1 = require('../utils/config.service');
var DataService = (function () {
    function DataService(http, itemsService, configService) {
        this.http = http;
        this.itemsService = itemsService;
        this.configService = configService;
        this._baseUrl = '';
        this._baseUrl = configService.getApiURI();
    }
    DataService.prototype.jwt = function () {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.access_token) {
            var headers = new http_1.Headers({ 'Authorization': 'Bearer ' + currentUser.access_token });
            headers.append("Content-Type", "application/json");
            return new http_1.RequestOptions({ headers: headers });
        }
    };
    DataService.prototype.getCategories = function () {
        return this.http.get(this._baseUrl + 'Cat/All', this.jwt()).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.createCategory = function (category) {
        return this.http.post(this._baseUrl + 'Cat/Save', category, this.jwt()).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.login = function (username, password) {
        var header = new http_1.Headers();
        header.append("Content-Type", "application/x-www-form-urlencoded");
        var data = "grant_type=password&username=" + username + "&password=" + password;
        return this.http.post(this._baseUrl + 'token', data, { headers: header }).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.register = function (userName, firstName, lastName, password) {
        var header = new http_1.Headers();
        header.append("Content-Type", "application/json");
        var data = { username: userName, firstName: firstName, lastName: lastName, password: password };
        return this.http.post(this._baseUrl + 'Account/Register', data, { headers: header }).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.logout = function () {
        localStorage.removeItem('currentUser');
    };
    DataService.prototype.updateCat = function (category) {
        return this.http.put(this._baseUrl + 'Cat/Update', category, this.jwt()).map(function (res) { return; }).catch(this.handleError);
    };
    DataService.prototype.deleteCat = function (category) {
        return this.http.delete(this._baseUrl + 'Cat/Delete?id=' + category.id, this.jwt()).map(function (res) { return; }).catch(this.handleError);
    };
    DataService.prototype.getUsers = function () {
        return this.http.get(this._baseUrl + 'Users/All', this.jwt()).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.getUseById = function (id) {
        return this.http.get(this._baseUrl + 'Users/Get/' + id, this.jwt()).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.createUser = function (user) {
        //var file = document.getElementById('filePhoto');
        //var formData = new FormData();
        //formData.append('fileObj', file.files[0]);
        //formData.append('request', JSON.stringify(user));
        //var xhr = new XMLHttpRequest();      
        //xhr.onreadystatechange = function () {
        //    if (xhr.readyState === 4 && xhr.status === 200) {
        //        alert(xhr.responseText);
        //        var data = JSON.parse(xhr.responseText);
        //        if (data !== undefined && data.Result.Status === 0) {
        //            console.log(data);
        //        }
        //        else {
        //            console.log(data.Result.Error[0]);
        //        }
        //    }
        //};
        //xhr.open("Post", this._baseUrl + 'Users/Save', true);
        //xhr.send(formData);
        return this.http.post(this._baseUrl + 'Users/Save', user, this.jwt()).map(function (res) { return res.json(); }).catch(this.handleError);
    };
    DataService.prototype.updateUser = function (user) {
        return this.http.post(this._baseUrl + 'Users/Save', user, this.jwt()).map(function (res) { return; }).catch(this.handleError);
    };
    DataService.prototype.deleteUser = function (id) {
        return this.http.delete(this._baseUrl + 'Users/Delete/' + id).map(function (res) { return; }).catch(this.handleError);
    };
    DataService.prototype.handleError = function (error) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors = '';
        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
        return Observable_1.Observable.throw(applicationError || modelStateErrors || 'Server error');
    };
    DataService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, items_service_1.ItemsService, config_service_1.ConfigService])
    ], DataService);
    return DataService;
}());
exports.DataService = DataService;
//# sourceMappingURL=data.service.js.map